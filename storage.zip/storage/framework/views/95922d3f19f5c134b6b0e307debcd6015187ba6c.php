<?php $__env->startSection('title', 'Print Invoice'); ?> 

<?php $__env->startSection('content'); ?> 

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Invoice</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        body{
            font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            color:#333;
            text-align:left;
            font-size:18px;
            margin:0;
        }
        .container{
            margin:0 auto;
            margin-top:35px;
            padding:40px;
            width:750px;
            height:auto;
            background-color:#fff;
        }
        caption{
            font-size:28px;
            margin-bottom:15px;
        }
        table{
            border:1px solid #333;
            border-collapse:collapse;
            margin:0 auto;
            width:740px;
        }
        td, tr, th{
            padding:12px;
            border:1px solid #333;
            width:185px;
        }
        th{
            background-color: #f0f0f0;
        }
        h4, p{
            margin:0px;
        }
    </style>
</head>
<body>
    <div class="container">
        <table>
            <caption>
                N.EL.D STORE Invoice
            </caption>
            <thead>
                <tr>
                    <th colspan="3">Invoice <strong>#<?php echo e($n_id); ?></strong></th>
                    <th><?php echo e($n_date); ?></th>
                </tr>
                <tr>
                    <td colspan="2">
                        <h4>Perusahaan: </h4>
                        <p>N.EL.D STORE<br>
                           Jl Airlangga 99, Surabaya<br>
                           085098632567<br>
                        </p>
                    </td>
                    <td colspan="2">
                        <h4>Pelanggan: </h4>
                        <p><?php echo e($c_name); ?><br>
                        <?php echo e($c_street); ?><br>
                        <?php echo e($c_phone); ?> <br>
                        <?php echo e($c_email); ?>

                        </p>
                    </td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nama Produk</th>
                    <th>Quantity</th>
                    <th>Harga Item</th>
                    <th>Discount</th>
                    <th>Total Harga Item</th>
                </tr>
                <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($row->product_name); ?></td>
                    <td><?php echo e($row->quantity); ?></td>
                    <td>Rp <?php echo e(number_format($row->selling_price)); ?></td>
                    <td><?php echo e($row->discount); ?></td>
                    <td>Rp <?php echo e($row->total_price); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th colspan="3">Subtotal</th>
                    <td>Rp. <input type="text" id="subtotal" name="subtotal" style="border: 0px;" readonly></td>
                </tr>
                <tr>
                    <th colspan="3">Total Discount</th>
                    <td>Rp. <input type="text" id="total_discount" name="total_discount" style="border: 0px;" readonly></td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3">Total Pembayaran</th>
                    <td>Rp. <input type="text" id="total_payment" name="total_payment" style="border: 0px;" readonly> </td>
                </tr>
            </tfoot>
        </table>
    </div>
</body>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('tambahan'); ?>

<script type="/admin/vendor/datatables/jquery.dataTables.min.js"></script>
<script type="/admin/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script type="/admin/js/demo/datatables-demo.js"></script>
<script type="text/javascript">

  function myFunction(id) {
    var quantity = document.getElementById("quantity"+id).value;
    var price = document.getElementById("price"+id).value;
    var subtotal = (quantity*price);
    document.getElementById("discount"+id).setAttribute("max", subtotal);

    var total_price = (quantity*price);
    document.getElementById("total_price"+id).value = total_price;
    document.getElementById("totaltext"+id).innerHTML = total_price;

    var totals = document.getElementsByClassName("total_price");

    var i;

    var total_p = 0;
    for (i=0; i< totals.length; ++i){
      total_p = total_p + Number(totals[i].value);
    }
    document.getElementById('subtotal').value = total_p;

    var discounts = document.getElementsByClassName("discount");

    var i;
    var total_disc = 0;
    for (i=0; i< discounts.length; ++i ){
      total_disc = total_disc + Number(discounts[i].value);
    }
    document.getElementById('total_discount').value = total_disc;

    document.getElementById('total_payment').value = total_p - total_disc;
  };


</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/sales/print_invoice.blade.php ENDPATH**/ ?>