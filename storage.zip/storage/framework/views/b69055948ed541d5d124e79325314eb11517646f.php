<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="card-body " style="background-color: #FFFFE0; width: 100%; height: 100%;">
<div class="card-header" style="background-color: #F4A460 ;">
<div class="chart-layer-2">
  <div class="col-md-6 chart-layer2-left">
     <h1 class="judul-data" style="text-align: center; font-family: 'URW Chancery L', cursive ;"><b> WELCOME TO N.E.L.D STORE,  <input type="hidden" name="user_id" value="<?php echo e(@session('user_id')); ?>"> <?php echo e(@session('first_name')); ?> <?php echo e(@session('last_name')); ?> ! </b></h1> 
  </div>

   <div class="col-md-6 chart-layer2-right">
     <!--climate start here-->
<div class="climate">
  <div class="col-md-8 climate-grids">
    <div class="climate-grid1">
      <div class="climate-gd1-top">
        <div class="col-md-6 climate-gd1top-left">
          <h4 id="date"></h4>
          <h3 style="color: white;" id="time" ></h3> 
          
            
          
          <script type="text/javascript">
              $(document).ready( function() {
                var date_now = new Date();
                const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
                var month = monthNames[date_now.getMonth()];
                var day = date_now.getDate();
                if (day < 10) 
                    day = "0" + day;
                var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                var dayName = days[date_now.getDay()];
                var today = dayName+ ", "+ day + " " + month + " " + date_now.getFullYear();
                var date = document.getElementById('date');
                date.innerHTML=today;

              });   

            var today= new Date();
            var time = today.getHours() + ":" + today.getMinutes();
            document.getElementById('time').innerHTML=time;


          </script>
   
        </div>
        <div class="col-md-6 climate-gd1top-right" style="padding-left: 60px;">
            <span class="clime-icon"> 
              <figure class="icons">
                <canvas id="partly-cloudy-day" width="64" height="64">
                </canvas>
              </figure>
            <script>
               var icons = new Skycons({"color": "#fff"}),
                  list  = [
                  "clear-night", "partly-cloudy-day",
                  "partly-cloudy-night", "cloudy", "rain", "sleet", "snow", "wind",
                  "fog"
                  ],
                  i;

                for(i = list.length; i--; )
                icons.set(list[i], list[i]);

                icons.play();
            </script>           
           </span>          
      
        </div>
      
      </div>
     
    </div>
  </div>
 
 
  <div class="clearfix"> </div>
</div>
<!--climate end here-->
  </div>
  <div class="clearfix"> </div>
</div>
 </div>

    <div class="market-updates">
      <div class="col-md-4 market-update-gd">
        <div class="market-update-block clr-block-1">
          <div class="col-md-8 market-update-left">
            <h3><?php echo e($total_product); ?> </h3>
            <h4>Total Produk Terjual</h4>
            <!--<p>Other hand, we denounce</p>-->
          </div>
          <div class="col-md-4 market-update-right">
            <i class="fa fa-file-text-o"> </i>
          </div>
          <div class="clearfix"> </div>
        </div>
      </div>
      <div class="col-md-4 market-update-gd">
        <div class="market-update-block clr-block-2">
         <div class="col-md-8 market-update-left">
          <h3>135</h3>
          <h4>Produk Terjual </h4>
          <p>Bulan ini</p>
          </div>
          <div class="col-md-4 market-update-right">
            <i class="fa fa-eye"> </i>
          </div>
          <div class="clearfix"> </div>
        </div>
      </div>
      <div class="col-md-4 market-update-gd">
        <div class="market-update-block clr-block-3">
          <div class="col-md-8 market-update-left">
            <h3>23</h3>
            <h4>Total Penjualan</h4>
            <!--<p>Other hand, we denounce</p>-->
          </div>
          <div class="col-md-4 market-update-right">
            <i class="fa fa-envelope-o"> </i>
          </div>
          <div class="clearfix"> </div>
        </div>
      </div>
       <div class="clearfix"> </div>
    </div>
<!--market updates end here-->
<br>
<!--main page chart start here-->
<div class="main-page-charts">
   <div class="main-page-chart-layer1">
    <div class="col-md-6 chart-layer1-left"> 
      <div class="glocy-chart">
      <div class="span-2c">  
                        <h3 class="tlt">Sales Analytics</h3>
                        <canvas id="bar" height="300" width="400" style="width: 400px; height: 300px;"></canvas>
                        <script>
                            var barChartData = {
                            labels : ["Jan","Feb","Mar","Apr","May","Jun","jul"],
                            datasets : [
                                {
                                    fillColor : "#FC8213",
                                    data : [65,59,90,81,56,55,40]
                                },
                                {
                                    fillColor : "#337AB7",
                                    data : [28,48,40,19,96,27,100]
                                }
                            ]

                        };
                            new Chart(document.getElementById("bar").getContext("2d")).Bar(barChartData);

                        </script>
                    </div>                    
      </div>
    </div>
    <div class="col-md-6 chart-layer1-right"> 
       <div class="prograc-blocks">
         <!--Progress bars-->
          <div class="home-progres-main">
             <h3>Total Sales</h3>
           </div>
          <div class='bar_group'>
          <div class='bar_group__bar thin' label='Rating' show_values='true' tooltip='true' value='343'></div>
          <div class='bar_group__bar thin' label='Quality' show_values='true' tooltip='true' value='235'></div>
          <div class='bar_group__bar thin' label='Amount' show_values='true' tooltip='true' value='550'></div>
          <div class='bar_group__bar thin' label='Farming' show_values='true' tooltip='true' value='456'></div>
        </div>
        <script src="js/bars.js"></script>

        <!--//Progress bars-->
        </div>
    </div>

   <div class="clearfix"> </div>
  </div>
 </div>
<!--main page chart layer2-->



          
     </div>


<?php $__env->stopSection(); ?>



<!--market updates updates-->
<!--
   <h4 style="text-align: center; position: absolute; align-content: center"><b> WELCOME TO N.E.L.D STORE ! </b></h4>
    <br><br>


<div class="main-page-charts">
   <div class="main-page-chart-layer1">
    <div class="col-md-6 chart-layer1-left"> 
      <div class="glocy-chart">
      <div class="span-2c">  
                        <h3 class="tlt">Sales Analytics</h3>
                        <canvas id="bar" height="300" width="400" style="width: 400px; height: 300px;"></canvas>
                        <script>
                            var barChartData = {
                            labels : ["Jan","Feb","Mar","Apr","May","Jun","jul"],
                            datasets : [
                                {
                                    fillColor : "#FC8213",
                                    data : [65,59,90,81,56,55,40]
                                },
                                {
                                    fillColor : "#337AB7",
                                    data : [28,48,40,19,96,27,100]
                                }
                            ]

                        };
                            new Chart(document.getElementById("bar").getContext("2d")).Bar(barChartData);

                        </script>
                    </div>                    
      </div>
    </div>
    <div class="col-md-6 chart-layer1-right"> 
      <div class="user-marorm">
      <div class="malorum-top">       
      </div>
      <div class="malorm-bottom">
        <span class="malorum-pro"> </span>
           <h4>Business Woman</h4>
         <h2>Nyoman Erlina Lani Diana</h2>
        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising.</p>
        <ul class="malorum-icons">
          <li><a href="#"><i class="fa fa-facebook"> </i>
            <div class="tooltip"><span>Facebook</span></div>
          </a></li>
          <li><a href="#"><i class="fa fa-twitter"> </i>
            <div class="tooltip"><span>Twitter</span></div>
          </a></li>
          <li><a href="#"><i class="fa fa-google-plus"> </i>
            <div class="tooltip"><span>Google</span></div>
          </a></li>
        </ul>
      </div>
       </div>
    </div>
   <div class="clearfix"> </div>
  </div>
 </div>


-->




<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/menu/dashboard.blade.php ENDPATH**/ ?>