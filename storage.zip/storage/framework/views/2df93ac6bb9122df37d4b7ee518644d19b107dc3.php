<?php $__env->startSection('title', 'Data Sale'); ?> 

<?php $__env->startSection('head'); ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js" type="text/javascript"></script>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('content'); ?> 

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
        <table border="1" width="100%" id="tableModal">
          <thead>
            <th style="text-align:center"><b>Nama Barang</b></th>
            <th style="text-align:center"><b>Harga</b></th>
          </thead>

          <tr style="cursor:pointer" onclick="pilihBarang(2)">
              <td style="text-align:center">Citos</td>
              <td style="text-align:center">2000</td>
          </tr>
          <tr style="cursor:pointer" onclick="pilihBarang(1)">
              <td style="text-align:center">Ciki</td>
              <td style="text-align:center">1000</td>
          </tr>
          <tr style="cursor:pointer" onclick="pilihBarang(3)">
              <td style="text-align:center">Curos</td>
              <td style="text-align:center">2400</td>
          </tr>
          <tr style="cursor:pointer" onclick="pilihBarang(4)">
              <td style="text-align:center">Pelem</td>
              <td style="text-align:center">3000</td>
          </tr>
          <tr style="cursor:pointer" onclick="pilihBarang(5)">
              <td style="text-align:center">Fanta</td>
              <td style="text-align:center">4500</td>
          </tr>
          <tr style="cursor:pointer" onclick="pilihBarang(6)">
              <td style="text-align:center">Sirup</td>
              <td style="text-align:center">2000</td>
          </tr>
        
        </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<!-- END Modal -->

<div class="card">
  <div class="card-header" style="background-color: #EEE8AA">
      <h1 class="judul-data"><b> Detail Transaction</b></h1> 
  </div>

    <div class="card-body" style="background-color: #FFFFE0; width: 100%; height: 100%;">
    <form action="/sales" method="post" id="catForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="nota_id" value="<?php echo e($nota_id); ?>">
        <h1 style="font-size: 18px; padding: 20px 0px 0px 48px;"><b> #ID Nota : <?php echo e($nota_id); ?> </b></h1>
        <div class="row" style="padding-left: 20px;">
          <div class="col-md-6">
             <div class="form-group" style="padding: 25px 40px 25px 25px; font-size: 18px;">
                  <div class="card_area" style="vertical-align: top;">
                      <label for="nota_date"><i class='far fa-calendar-alt' style='font-size:18px'></i> Date </label>  
                    <div class="form-group">
                      <input type="date" id="nota_date" name="nota_date" readonly> 
                    </div>
                  </div>

               
                    <div style="vertical-align: top; width: 30%">
                      <label for="user"><i class='fas fa-user-circle' style='font-size:18px'></i> User</label>
                    </div>
                  
                      <div class="form-group">
                         <input type="hidden" name="user_id" value="<?php echo e(@session('user_id')); ?>"> <?php echo e(@session('first_name')); ?> <?php echo e(@session('last_name')); ?>

                      </div>


                    <div style="vertical-align: top;">
                      <label for="customer"><i class='fas fa-user-alt' style='font-size:18px'></i> Customer</label>
                    </div>
            
                      <div>
                        <select id="customer_id" name="customer_id" class="form-control <?php if ($errors->has('customer_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" style="width: 21em; height: 2.5em; font-size: 16px;" value="<?php echo e(old('customer_id')); ?>" >
                          <option disabled selected readonly>- Pilih Customer -</option>
                           <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->customer_id); ?>">
                              <?php echo e($customer->first_name); ?> <?php echo e($customer->last_name); ?>

                            </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if ($errors->has('customer_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_id'); ?> 
                          <div class="invalid-feedback form-error" >
                            <?php echo e($message); ?>

                          </div>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                 
              </div>
            </div>

        <div class="col-md-6">
           <div class="form-group" style="padding: 25px 40px 25px 25px;">
            
              <div>
              <label for="product_id" style="font-size: 18px;"><i class="fa fa-product-hunt" style="font-size:18px"></i> Product</label>
              <br>
              <input type="text" id="myText" value="" onkeyup="getVal(event)" onfocus="select()">
              </div>
                
              <br>
              <input type="button" class="btn btn-flat btn-warning" value="Add Product" onclick="modal()"></input>
          
            </div>
        </div>
    </div>


    <br>
    <br>

<table width="100%" border="1" id="keranjang">
  <thead>
    <th width="40%"><b>Nama</b></th>
    <th width="20%"><b>Harga</b></th>
    <th width="10%"><b>Qty</b></th>
    <th width="20%"><b>Subtotal</b></th>
    <th width="10%"><b>action</b></th>
  </thead>
</table>
<br>
<br>
<h3>Total: Rp. <input type="text" name="total" id="total" value="0" readonly></h3>

      <!--================Cart Area =================-->
     <!-- <section class="cart_area"> -->
      <!--
        <div class="container">
          <div class="cart_inner">
            <div class="table-responsive" style="width: 95%">
              <table class="table" id="keranjang">
                <thead>
                  <tr>
                    <th scope="col">ID Product</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Selling Price</th>
                    <th scope="col">Discount</th>
                    <th scope="col">Total Price</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                 

                </tbody>
              </table>
            </div>
          </div>
        </div>
      -->
    <!--  </section> -->
      <!--================End Cart Area =================-->
      <!--
      <br>
      
         <div class="row" style="padding-left: 25px;">
            <div style="padding: 10px 40px 25px 25px;" >
                <div>
                <h1 style="font-size: 18px ">Sub Total : Rp. <input type="text" id="subtotal" name="subtotal" style="border: 0px;" readonly> </h1>
                </div>

                <br>
      
               <div>
                  <h1 style="font-size: 18px ">Total Discount : Rp. <input type="text" id="total_discount" name="total_discount" style="border: 0px;" readonly> </h1>
                </div>

                <br>
                
                 <div>
                    <h1 style="font-size: 18px ">Total Payment : Rp. <input type="text" id="total_payment" name="total_payment" value="0" style="border: 0px;" readonly> </h1>
                  </div>

              </div>
         </div>
       -->

            <div style="padding-left: 800px;">
                <input type="submit" class="btn btn-flat btn-lg-10 btn-success" value="Process Transaction">
            </div>

            <br>
          </form>
     </div>
</div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('tambahan'); ?>

<script>

$(document).ready( function() {
    var now = new Date();
    var month = (now.getMonth() + 1);               
    var day = now.getDate();
    if (month < 10) 
        month = "0" + month;
    if (day < 10) 
        day = "0" + day;
    var today = now.getFullYear() + '-' + month + '-' + day;
    $('#nota_date').val(today);
});


window.onload=function(){
  document.getElementById('total').value=0;
}

var arrBarang = new Array(new Array(1, 'ciki', 1000),
                          new Array(2, 'citos', 2000),
                          new Array(3, 'curos', 2400),
                          new Array(4, 'pelem', 3000),
                          new Array(5, 'Fanta', 4500),
                          new Array(6, 'sirup', 2000) );

var colnum=0;

function modal()
{
    $("#myModal").modal("show");
}

function getVal(event)
{  
    console.log(event.key);
}

function pilihBarang(id)
{
  for(var i=0; i<arrBarang.length; i++)
  {
    if(arrBarang[i][0]==id)
      break;
  }
  console.log(arrBarang[i]);
  $("#myModal").modal("hide");

  var table = document.getElementById('keranjang');

  var flag=-1;

  for(var z=1; z<table.rows.length; z++)
  {
    if(table.rows[z].childNodes[0].childNodes[2].value == id)
    {
      flag=z;
      break;
    }
  }

  if(flag != -1)
  {
    var qty = table.rows[flag].childNodes[2].childNodes[0];
    qty.value = parseInt(qty.value) + 1;
    var row_id = table.rows[flag].id;
    updateSubtotal(row_id);
  }
  else
  {
    var row = table.insertRow(table.rows.length);
    var idrow = 'col'+colnum;
    row.setAttribute('id',idrow);
    colnum++;

    var cel_1=row.insertCell(0);
    var cel_2=row.insertCell(1);
    var cel_3=row.insertCell(2);
    var cel_4=row.insertCell(3);
    var cel_5=row.insertCell(4);

    cel_1.innerHTML = '<input type="text" name="barang[]" value="'+arrBarang[i][1]+'" style="background:transparent; border:none; text-align:center; width=100%" readonly>\
                      <input type="hidden" name="id[]" value="'+arrBarang[i][0]+'">';
    cel_2.innerHTML = '<input type="text" name="harga[]" value="'+arrBarang[i][2]+'" readonly>';
    cel_3.innerHTML = '<input type="text" name="qty[id]" value="1" onkeyup="updateSubtotal(\''+idrow+'\')" onfocus="select()">';
    cel_4.innerHTML = '<input type="text" name="subtotal[]" value="'+arrBarang[i][2]+'" readonly>';
    cel_5.innerHTML = '<button onclick="hapusEl(\''+idrow+'\')">Del</button>';
  }
  updateTotal();
}

function hapusEl(idRow)
{
  document.getElementById(idRow).remove();

  updateTotal();
}

function updateSubtotal(id)
{
  
  //hanya menerima input angka
  
  var row = document.getElementById(id);
  var qty = row.childNodes[2].childNodes[0].value;    
  var harga = row.childNodes[1].childNodes[0].value;
  
  var subTot = harga*qty;

  var colSubTot = row.childNodes[3].childNodes[0];
  colSubTot.value = subTot;

  updateTotal();
    
}

function updateTotal()
{
  var table = document.getElementById('keranjang');
  var total=0;
  for(var i=1; i<table.rows.length; i++)
  {
    total = total + parseInt(table.rows[i].childNodes[3].childNodes[0].value);
  }

  document.getElementById('total').value=total;
}




</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/sales/cart.blade.php ENDPATH**/ ?>