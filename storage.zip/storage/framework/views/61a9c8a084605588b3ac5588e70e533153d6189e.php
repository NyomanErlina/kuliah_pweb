<?php $__env->startSection('title', 'Data Sale'); ?> 

<?php $__env->startSection('content'); ?> 


<div class="form-input " style=" width: 70%">
    <div class="forminput-head">
              <h1>Form Update Data Sale</h1>
    </div>
      <div class="forminput-block">
          <form method="post" action="/sales/update/<?php echo e($sales->nota_id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

              <div>
                  <b style="padding-left: 18px;">ID Nota : <?php echo e($sales->nota_id); ?></b>
              </div>
          
              <br>

              <div class="col-md-6">
                  <label for="inputCustomerID"><b>*</b>Customer Name</label>
                  <select id="inputCustomerID" name="customer_id" value="<?php echo e($sales->customer_id); ?>" class="<?php if ($errors->has('customer_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('customer_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_id'); ?> 
                   <div class="invalid-feedback form-error"  >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->customer_id); ?>" <?php echo e($customer->customer_id == $sales->customer_id ? 'selected':''); ?>>
                      <?php echo e($customer->first_name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                  </select>
              </div>
            


              <div class="col-md-6">
                  <label for="inputUserID"><b>*</b>User Name</label>
                  <select id="inputUserID" name="user_id" value="<?php echo e($sales->user_id); ?>" class=" <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('user_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user_id'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->user_id); ?>" <?php echo e($user->user_id == $sales->user_id ? 'selected':''); ?>>
                      <?php echo e($user->first_name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </select>
              </div>

               
              <div class="col-md-6" >
                  <label><b>*</b>Nota Date</label>
                  <input type="date" name="nota_date" value="<?php echo e($sales->nota_date); ?>" class="<?php if ($errors->has('nota_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nota_date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" style="height: 50px">
                  <?php if ($errors->has('nota_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nota_date'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>


                <div class="col-md-6" >
                  <label><b>*</b>Total Payment</label>
                  <input type="number" min="0" name="total_payment" value="<?php echo e($sales->total_payment); ?>" class=" <?php if ($errors->has('total_payment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('total_payment'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('total_payment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('total_payment'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>


                 <br><br>
                <b style="color: orange; font-size: 15px; padding: 15px 0px 15px 40em;" >*Wajib Diisi !</b>
                <br><br>


              <button type="submit" class="submit">Change</button>

           
            </form>
      </div>
  </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/sales/edit_sales.blade.php ENDPATH**/ ?>