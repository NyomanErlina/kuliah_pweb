<?php $__env->startSection('title', 'Home User'); ?> 

<?php $__env->startSection('content'); ?> 


<div class="card">
<p>Hallo, <?php echo e(@session('name')); ?>. Apakabar?</p>

            <h2>* Email kamu : <?php echo e(Session::get('email')); ?></h2>
            <h2>* Status Login : <?php echo e(Session::get('login')); ?></h2>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views//users/home_users.blade.php ENDPATH**/ ?>