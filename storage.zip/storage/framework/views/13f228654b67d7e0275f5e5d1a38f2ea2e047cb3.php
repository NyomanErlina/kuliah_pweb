<?php $__env->startSection('title', 'Data Sales'); ?> 

<?php $__env->startSection('content'); ?> 



<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs " >
      <li class="nav-item nav-hover">
        <a class="active" href="<?php echo e(url('/sales')); ?>  " style="color: black;"><b> Data Sales </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/sales/trash_sales')); ?>" style="color: black;"><b> Dustbin </b></a>
      </li>
 
    </ul>
  </div>

          <?php if(session('status')): ?>
                <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                 </div>
            <?php endif; ?>


           <div class="card-header" style="background-color: #EEE8AA">
                <h1 class="judul-data"><b> Data Sales</b></h1> 
            </div>
                  
         
    <div class="card-body" style="background-color: #FFFFE0; width: 100%; height: 100%;">
          
           <a class="btn-input" href="/sales/create" style="margin-right: 60px;" >  <img src="<?php echo e(asset('images/icon-plus.png')); ?>" width="25" height="25"><b> Input Data </b></a>

            <table style="width: 90%;">
              <thead>
                
                <tr>
                 <th scope="col">Nota ID</th>
                  <th scope="col">Customer Name</th>
                  <th scope="col">User Name</th>
                  <th scope="col">Nota Date</th>
                  <th scope="col">Total Payment</th>
                  <th scope="col">Status</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                      <td><?php echo e($sale->nota_id); ?></td>
                      <td><?php echo e($sale->c_fullname); ?></td>
                      <td><?php echo e($sale->u_fullname); ?></td>
                      <td><?php echo e($sale->nota_date); ?></td>
                      <td><?php echo e($sale->total_payment); ?></td>
                      <td><?php echo e($status); ?></td>
                      <td>
                          
                        <div class="" >
                            <a href="/sales/delete/<?php echo e($sale->nota_id); ?>" style="color: black" onclick="return confirm('Anda yakin ingin menghapus data ini?')" > <img src="<?php echo e(asset('images/icon-delete.png')); ?>" width="20" height="20" style="padding-left: 2px" > <br> <b> Delete </b></a>

                        </div>
                      <!--
                        <div class=" col-md-6" >
                            <a href="/sales/edit/<?php echo e($sale->nota_id); ?>" style="color: black"> <img src="<?php echo e(asset('images/icon-edit.png')); ?>" width="20" height="20"> <br><b> Edit </b></a>
                        </div>
                      -->

                        
                        <div class=" col-md-6" >
                          <a href="<?php echo e(route('sales.print_invoice', $sale->nota_id)); ?>" class="btn btn-secondary btn-sm">Print</a>
                        </div>
                       
                
                    <!--
                          <div class="form-group col-md-4 " >
                            <a href="/sales/sales_details" style="color: black ;" class="button"> <img src="<?php echo e(asset('images/icon-arrow-down.png')); ?>" width="20" height="20"> <br><b> Detail </b></a>
                          </div> 
                      -->

                      </td>


                </tr>

            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <br><br><br>
      </div>
</div>
      

<br><br><br>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/sales/sales.blade.php ENDPATH**/ ?>