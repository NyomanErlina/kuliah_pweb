<?php $__env->startSection('title', 'Data User'); ?> 

<?php $__env->startSection('content'); ?> 


 <div class="form-input ">
    <div class="forminput-head">
              <h1>Form Update Data User</h1>
    </div>
      <div class="forminput-block">
          <form method="post" action="/users/update/<?php echo e($user->user_id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

              <div>
                  <b style="padding-left: 18px;">ID User : <?php echo e($user->user_id); ?></b>
              </div>
          
              <br>
              <div class="col-md-6">
                  <label><b>*</b>First Name</label>
                  <input type="text" name="first_name" value="<?php echo e($user->first_name); ?>" class="<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

                <div class="col-md-6">
                  <label><b>*</b>Last Name</label>
                  <input type="text" name="last_name" value="<?php echo e($user->last_name); ?>" class="<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
              



              <div class="col-md-6">
                  <label><b>*</b>Email</label>
                  <input type="email" name="email" value="<?php echo e($user->email); ?>" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
              

      
                <div class="col-md-6">
                  <label><b>*</b>Phone</label>
                  <input type="number" min="0" name="phone" value="<?php echo e($user->phone); ?>" class="<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                </div>
                

              <div class="col-md-6">
                 <label><b>*</b>Password</label>
                <input type="password" name="password" value="<?php echo e($user->password); ?>" class=" <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

              </div>
             
                <div class="col-md-6">
                  <label><b>*</b>Job Status</label>
                  <input type="text" name="job_status" value="<?php echo e($user->job_status); ?>" class=" <?php if ($errors->has('job_status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('job_status'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('job_status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('job_status'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <br><br>
                <b style="color: orange; font-size: 15px; padding: 15px 0px 15px 15px;" >*Wajib Diisi !</b>
                <br><br>
              
          
              <button type="submit" class="submit">Change</button>
            </form>
      </div>
  </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/users/edit_users.blade.php ENDPATH**/ ?>