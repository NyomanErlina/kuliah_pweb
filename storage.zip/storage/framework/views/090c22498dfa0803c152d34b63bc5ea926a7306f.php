<!DOCTYPE html>
<html>
<head>
  <title>Laporan Penjualan</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
  <style type="text/css">
    table tr td,
    table tr th{
      font-size: 9pt;
    }
  </style>
  <center>
    <h3>Laporan Penjualan Tahun 2020</h3>
   
  </center>
  <br>

 
  <table class='table table-bordered'>
              <thead>
                
                <tr>
                 <th scope="col">Nota ID</th>
                  <th scope="col">Customer Name</th>
                  <th scope="col">User Name</th>
                  <th scope="col">Nota Date</th>
                  <th scope="col">Total Payment</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                      <td><?php echo e($sale->nota_id); ?></td>
                      <td><?php echo e($sale->c_fullname); ?></td>
                      <td><?php echo e($sale->u_fullname); ?></td>
                      <td><?php echo e($sale->nota_date); ?></td>
                      <td><?php echo e($sale->total_payment); ?></td>
                </tr>

            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
  </table>
  <br>
  <h5>Detail Penjualan</h5>
 <br>
  <table class='table table-bordered'>
              <thead>
                <tr>
                  <th scope="col">Nota ID</th>
                  <th scope="col">Product Name</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Selling Price</th>
                  <th scope="col">Discount</th>
                  <th scope="col">Total Price</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $salesdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detsal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                      <td><?php echo e($detsal->nota_id); ?></td>
                      <td><?php echo e($detsal->product_name); ?></td>
                      <td><?php echo e($detsal->quantity); ?></td>
                      <td><?php echo e($detsal->selling_price); ?></td>
                      <td><?php echo e($detsal->discount); ?></td>
                      <td><?php echo e($detsal->total_price); ?></td>
                   
                </tr>

            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>

  </table>
</body>
</html><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/sales/laporan_pdf.blade.php ENDPATH**/ ?>