<?php $__env->startSection('title', 'Data Detail Sale'); ?> 

<?php $__env->startSection('content'); ?> 


<div class="card">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs " >
      <li class="nav-item">
        <a  href="<?php echo e(url('/customers/create')); ?> " style="color: black;"><b> Customers </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/users/create ')); ?>" style="color: black;"><b> Users </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/categories/create')); ?>" style="color: black;"><b> Categories </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/products/create')); ?>" style="color: black;"><b> Products </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/sales/create')); ?>" style="color: black;"><b> Sales </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a class="active" href="<?php echo e(url('/salesdet/create')); ?>" style="color: black;"><b> Sales Details</b></a>
      </li>
    </ul>
  </div>



<div class="form-input " style=" width: 60%;">
    <div class="forminput-head">
              <h1>Form Input Data Detail Sales</h1>
    </div>
      <div class="forminput-block">
          <form method="post" action="/salesdet">
            <?php echo csrf_field(); ?>

              <div class="col-md-6">
                  <label for="inputNotaID"><b>*</b>ID Nota</label>
                  <select id="inputNotaID" name="nota_id" value="<?php echo e(old('nota_id')); ?>" class="<?php if ($errors->has('nota_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nota_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"> 
                  <?php if ($errors->has('nota_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nota_id'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                  <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($sal->nota_id); ?>"
                      >
                      <?php echo e($sal->nota_id); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                  </select>
              </div>
            


              <div class="col-md-6">
                  <label for="inputProductID"><b>*</b>Product Name</label>
                  <select id="inputProductID" name="product_id" value="<?php echo e(old('product_id')); ?>" class=" <?php if ($errors->has('product_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('product_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_id'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->product_id); ?>">
                      <?php echo e($product->product_name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

               
              <div class="col-md-3" >
                  <label><b>*</b>Quantity</label>
                  <input type="number" min="0" name="quantity" value="<?php echo e(old('quantity')); ?>" class="<?php if ($errors->has('quantity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantity'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('quantity')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('quantity'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                 <div class="col-md-3" >
                  <label><b>*</b>Discount</label>
                  <input type="number" min="0" name="discount" value="<?php echo e(old('discount')); ?>" class=" <?php if ($errors->has('discount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('discount'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('discount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('discount'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="col-md-6" >
                  <label><b>*</b>Selling Price</label>
                  <input type="number" min="0" name="selling_price" value="<?php echo e(old('selling_price')); ?>" class=" <?php if ($errors->has('selling_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('selling_price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('selling_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('selling_price'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                

                <div class=" col-md-6" >
                  <label><b>*</b>Total Price</label>
                  <input type="number" min="0" name="total_price" value="<?php echo e(old('total_price')); ?>" class=" <?php if ($errors->has('total_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('total_price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('total_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('total_price'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                </div>
                
               
              <div class=" col-md-6" style="margin-top: 27px;">
                    <button type="submit" class="submit">Submit</button>
              </div>

               <b style="color: orange; font-size: 15px; margin : 50px 0px 5px 500px;" >*Wajib Diisi !</b>
            </form>
      </div>
  </div>
</div>





<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/salesdet/create_sales_details.blade.php ENDPATH**/ ?>