<!DOCTYPE html>

    <head>
       <title>Belajar Laravel</title>
    </head>
    <body>
       <h3>Percobaan Pertama View</h3>
       <p>Membuka web dari view!</p>
    </body>
</html>
