<?php $__env->startSection('title', 'Data Customers'); ?> 

<?php $__env->startSection('content'); ?> 


<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs " >
      <li class="nav-item nav-hover">
        <a class="active" href="<?php echo e(url('/customers')); ?> " style="color: black;"><b> Data Customers </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/customers/trash_customers')); ?>" style="color: black;"><b> Dustbin </b></a>
      </li>
 
    </ul>
  </div>

          <?php if(session('status')): ?>
                <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                 </div>
            <?php endif; ?>

   <div class="card-header" style="background-color: #EEE8AA">
       <h1 class="judul-data"><b> Data Customers </b></h1> 
  </div>         
         
    <div class="card-body" style="background-color: #FFFFE0; width: 100%; height: 100%;">
           <a class="btn-input" href="/customers/create"  >  <img src="<?php echo e(asset('images/icon-plus.png')); ?>" width="25" height="25"><b> Input Data </b></a>
       
            <table style="width: 95%;">
              <thead>
                <tr>
                  <th scope="col">Customer ID</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Phone</th>
                  <th scope="col">Email</th>
                  <th scope="col">Street</th>
                  <th scope="col">City</th>
                  <th scope="col">State</th>
                  <th scope="col">Zip Code</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>

              <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($customer->customer_id); ?></td>
                  <td><?php echo e($customer->first_name); ?></td>
                  <td><?php echo e($customer->last_name); ?></td>
                  <td><?php echo e($customer->phone); ?></td>
                  <td><?php echo e($customer->email); ?></td>
                  <td><?php echo e($customer->street); ?></td>
                  <td><?php echo e($customer->city); ?></td>
                  <td><?php echo e($customer->state); ?></td>
                  <td><?php echo e($customer->zip_code); ?></td>
                  <td>
                    <div class="col-md-6" >
                         <a  href="/customers/delete/<?php echo e($customer->customer_id); ?>" style="color: black" onclick="return confirm('Anda yakin ingin menghapus data ini?')" > <img src="<?php echo e(asset('images/icon-delete.png')); ?>" style="padding-left: 2px ; width: 20px ; height: 20px;" > <br> <b> Delete </b></a>

                    </div>
                    <div class="col-md-6">
                        <a href="/customers/edit/<?php echo e($customer->customer_id); ?>" style="color: black"> <img src="<?php echo e(asset('images/icon-edit.png')); ?>" style="width: 20px ; height: 20px;"> <br><b> Edit </b></a>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <br><br><br>
        </div>
</div>

<br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/customers/customers.blade.php ENDPATH**/ ?>