<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

  <div class="card-header" style="background-color: #F4A460 ;">
      <h1 class="judul-data" style="text-align: center; font-family: 'URW Chancery L', cursive ;"><b> WELCOME TO N.E.L.D STORE! </b></h1> 
  </div>

    <div class="card-body " style="background-color: #FFFFE0; width: 100%; height: 100%;">
      <divS>
          <img style="width: 50%; height: 50%" src="<?php echo e(asset('images/dashboard-icon.png')); ?>" alt="">
         

          <div class="col-md-6 chart-layer1-left"> 
      <div class="glocy-chart">
      <div class="span-2c">  
                        <h3 class="tlt">Sales Analytics</h3>
                        <canvas id="bar" height="300" width="400" style="width: 400px; height: 300px;"></canvas>
                        <script>
                            var barChartData = {
                            labels : ["Jan","Feb","Mar","Apr","May","Jun","jul"],
                            datasets : [
                                {
                                    fillColor : "#FC8213",
                                    data : [65,59,90,81,56,55,40]
                                },
                                {
                                    fillColor : "#337AB7",
                                    data : [28,48,40,19,96,27,100]
                                }
                            ]

                        };
                            new Chart(document.getElementById("bar").getContext("2d")).Bar(barChartData);

                        </script>
                    </div>                    
            </div>
          </div>

          <br><br><br><br>
          <br><br><br>
      </div>
          
     </div>

    <br>
<?php $__env->stopSection(); ?>



<!--market updates updates-->
<!--
   <h4 style="text-align: center; position: absolute; align-content: center"><b> WELCOME TO N.E.L.D STORE ! </b></h4>
    <br><br>


<div class="main-page-charts">
   <div class="main-page-chart-layer1">
    <div class="col-md-6 chart-layer1-left"> 
      <div class="glocy-chart">
      <div class="span-2c">  
                        <h3 class="tlt">Sales Analytics</h3>
                        <canvas id="bar" height="300" width="400" style="width: 400px; height: 300px;"></canvas>
                        <script>
                            var barChartData = {
                            labels : ["Jan","Feb","Mar","Apr","May","Jun","jul"],
                            datasets : [
                                {
                                    fillColor : "#FC8213",
                                    data : [65,59,90,81,56,55,40]
                                },
                                {
                                    fillColor : "#337AB7",
                                    data : [28,48,40,19,96,27,100]
                                }
                            ]

                        };
                            new Chart(document.getElementById("bar").getContext("2d")).Bar(barChartData);

                        </script>
                    </div>                    
      </div>
    </div>
    <div class="col-md-6 chart-layer1-right"> 
      <div class="user-marorm">
      <div class="malorum-top">       
      </div>
      <div class="malorm-bottom">
        <span class="malorum-pro"> </span>
           <h4>Business Woman</h4>
         <h2>Nyoman Erlina Lani Diana</h2>
        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising.</p>
        <ul class="malorum-icons">
          <li><a href="#"><i class="fa fa-facebook"> </i>
            <div class="tooltip"><span>Facebook</span></div>
          </a></li>
          <li><a href="#"><i class="fa fa-twitter"> </i>
            <div class="tooltip"><span>Twitter</span></div>
          </a></li>
          <li><a href="#"><i class="fa fa-google-plus"> </i>
            <div class="tooltip"><span>Google</span></div>
          </a></li>
        </ul>
      </div>
       </div>
    </div>
   <div class="clearfix"> </div>
  </div>
 </div>


-->




<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views//menu/dashboard.blade.php ENDPATH**/ ?>