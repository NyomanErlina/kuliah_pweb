<?php $__env->startSection('title', 'Data Sales Details'); ?> 

<?php $__env->startSection('content'); ?> 




<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs " >
      <li class="nav-item nav-hover">
        <a class="active" href="<?php echo e(url('/salesdet')); ?> " style="color: black;"><b> Data Sales Details</b></a>
      </li>
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/salesdet/trash_sales_details')); ?>" style="color: black;"><b> Dustbin </b></a>
      </li>
 
    </ul>
  </div>

          <?php if(session('status')): ?>
                <div class="alert alert-success">
                      <?php echo e(session('status')); ?>

                 </div>
            <?php endif; ?>


           <div class="card-header" style="background-color: #EEE8AA">
                <h1 class="judul-data"><b> Data Sales Details</b></h1> 
            </div>
                  
         
    <div class="card-body" style="background-color: #FFFFE0; width: 100%; height: 100%;">
          
      <br><br>      

            <table style="width: 90%;">
              <thead>
               
                <tr>
                  <th scope="col">Nota ID</th>
                  <th scope="col">Product Name</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Selling Price</th>
                  <th scope="col">Discount</th>
                  <th scope="col">Total Price</th>
               
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $salesdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detsal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                      <td><?php echo e($detsal->nota_id); ?></td>
                      <td><?php echo e($detsal->product_name); ?></td>
                      <td><?php echo e($detsal->quantity); ?></td>
                      <td><?php echo e($detsal->selling_price); ?></td>
                      <td><?php echo e($detsal->discount); ?></td>
                      <td><?php echo e($detsal->total_price); ?></td>
                   
                </tr>

            
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <br><br><br>
      </div>
</div>
      


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views//salesdet/sales_details.blade.php ENDPATH**/ ?>