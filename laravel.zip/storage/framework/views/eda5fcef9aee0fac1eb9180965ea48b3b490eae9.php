<?php $__env->startSection('title', 'Data Customers'); ?> 

<?php $__env->startSection('content'); ?>


<div class="card">
  

  <div class="form-input">
    <div class="forminput-head">
        <h1>Form Input Data Customer</h1>
    </div>

      <div class="forminput-block">
          <form method="post" action="/customers">
            <?php echo csrf_field(); ?>
              <div class="col-md-6" >
                  <label><b>*</b>First Name</label>
                  <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" class="<?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>


                <div class="col-md-6" >
                  <label><b>*</b>Last Name</label>
                  <input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>" class="<?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
              

      
                <div class="col-md-6">
                  <label><b>*</b>Phone</label>
                  <input type="number" min="0" name="phone" value="<?php echo e(old('phone')); ?>" class="<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class=" col-md-6">
                  <label><b>*</b>Email</label>
                  <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
              
              <div style="padding-left: 15px; padding-right: 15px;">
                <label><b>*</b>Street</label>
                <input type="text" name="street" value="<?php echo e(old('street')); ?>" class=" <?php if ($errors->has('street')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('street'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('street')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('street'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

                <div class="col-md-6">
                  <label><b>*</b>City</label>
                  <input type="text" name="city" value="<?php echo e(old('city')); ?>" class=" <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>

                <div class="col-md-4">
                  <label for="inputState"><b>*</b>State</label>
                  <input id="inputState" type="text" name="state" value="<?php echo e(old('state')); ?>" class=" <?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                  </input>
                </div>

                <div class=" col-md-2">
                  <label for="inputZip"><b>*</b>Zip Code</label>
                  <input type="number" min="0" id="inputZip" name="zip_code" value="<?php echo e(old('zip_code')); ?>" class=" <?php if ($errors->has('zip_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zip_code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('zip_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zip_code'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
               <br><br>
                <b style="color: orange; font-size: 15px; padding: 15px 0px 15px 15px;" >*Wajib Diisi !</b>
                <br><br>
                <button type="submit" class="submit">Submit</button>
            </form>
      </div>
  </div>
</div>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/customers/create_customers.blade.php ENDPATH**/ ?>