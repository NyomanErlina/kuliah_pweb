<?php $__env->startSection('title', 'Table Master'); ?>

<?php $__env->startSection('content'); ?>



                   
                            
                           
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/menu/table_master.blade.php ENDPATH**/ ?>