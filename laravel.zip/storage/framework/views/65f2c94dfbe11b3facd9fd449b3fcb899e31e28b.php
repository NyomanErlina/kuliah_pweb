<?php $__env->startSection('title', 'Data Category'); ?> 

<?php $__env->startSection('content'); ?> 



<div class="card">
  
 <div class="form-input " style=" width: 55%">
    <div class="forminput-head">
              <h1>Form Input Data Category</h1>
    </div>
      <div class="forminput-block">
          <form method="post" action="/categories">
            <?php echo csrf_field(); ?>
              <div>
                  <label><b>*</b>Category Name</label>
                  <input type="text" name="category_name" value="<?php echo e(old('category_name')); ?>" class="<?php if ($errors->has('category_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('category_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_name'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              
                <b style="color: orange; font-size: 15px; padding: 15px 0px 15px 15px;" >*Wajib Diisi !</b>
                <br><br>
              <button type="submit" class="submit">Submit</button>
            </form>
      </div>
  </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/categories/create_categories.blade.php ENDPATH**/ ?>