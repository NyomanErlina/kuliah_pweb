<?php $__env->startSection('title', 'Data Products'); ?> 

<?php $__env->startSection('content'); ?> 



<div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-tabs card-header-tabs " >
      <li class="nav-item nav-hover">
        <a href="<?php echo e(url('/products')); ?> " style="color: black;"><b> Data Products </b></a>
      </li>
      <li class="nav-item nav-hover">
        <a class="active" href="<?php echo e(url('/products/trash_products')); ?>" style="color: black;"><b> Dustbin </b></a>
      </li>
 
    </ul>
  </div>

 
        <div class="card-header" style="background-color: #EEE8AA">
          <h1 class="judul-data">Data Products yang Telah Dihapus </h1>
        </div>

          <div class="card-body" style="background-color: #FFFFE0; width: 100%; height: 100%;">
             <a class="btn-input" href="/products/restore_all" style="margin-right: 60px;"  > <b> Restore All</b></a>
             
            <table style="width: 90%;">
              <thead>
               
                <tr>
                  <th scope="col">Product ID</th>
                  <th scope="col">Category Name</th>
                  <th scope="col">Product Name</th>
                  <th scope="col">Product Price</th>
                  <th scope="col">Product Stock</th>
                  <th scope="col">Explanation</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($product->product_id); ?></td>
                  <td><?php echo e($product->category_name); ?></td>
                  <td><?php echo e($product->product_name); ?></td>
                  <td><?php echo e($product->product_price); ?></td>
                  <td><?php echo e($product->product_stock); ?></td>
                  <td><?php echo e($product->explanation); ?></td>
                  <td>
                  
                      <div>
                           <a href="/products/restore/<?php echo e($product->product_id); ?>" style="color: black"  > <img src="<?php echo e(asset('images/icon-edit.png')); ?>" width="20" height="20"> <br> <b> Restore </b></a>

                      </div>
    
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <br><br><br>
          </div>
      </div>
      
 <br><br><br><br><br>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views//products/trash_products.blade.php ENDPATH**/ ?>