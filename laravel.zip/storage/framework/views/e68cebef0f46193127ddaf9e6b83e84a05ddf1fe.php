<?php $__env->startSection('title', 'Data Product'); ?> 

<?php $__env->startSection('content'); ?> 

<div class="card">

<div class="form-input " style="width: 70%">
    <div class="forminput-head">
              <h1>Form Input Data Product</h1>
    </div>
      <div class="forminput-block">
          <form method="post" action="/products">
            <?php echo csrf_field(); ?>

              <div class="col-md-6">
                  <label for="inputCategoryID"><b>*</b>Category Name</label>
                  <select id="inputCategoryID" name="category_id" value="<?php echo e(old('category_id')); ?>" class=" <?php if ($errors->has('category_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('category_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_id'); ?> 
                   <div class="invalid-feedback form-error">
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->category_id); ?>"
                      >
                      <?php echo e($category->category_name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

              <div class="col-md-6">
                <label><b>*</b>Product Name</label>
                  <input type="text" name="product_name" value="<?php echo e(old('product_name')); ?>" class="<?php if ($errors->has('product_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('product_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_name'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              
              
              <div class="col-md-6" >
                  <label><b>*</b>Product Price</label>
                  <input type="number" min="0" name="product_price" value="<?php echo e(old('product_price')); ?>" class=" <?php if ($errors->has('product_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_price'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('product_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_price'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

              <div class=" col-md-6">
                  <label><b>*</b>Product Stock</label>
                  <input type="number" min="0" name="product_stock" value="<?php echo e(old('product_stock')); ?>" class="<?php if ($errors->has('product_stock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_stock'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <?php if ($errors->has('product_stock')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_stock'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

              </div>
               
              <div style="margin-left: 15px; margin-right: 15px;">
                 <label>Explanation</label>
                  <textarea name="explanation" value="<?php echo e(old('explanation')); ?>" class=" <?php if ($errors->has('explanation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('explanation'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"></textarea>
                  <?php if ($errors->has('explanation')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('explanation'); ?> 
                   <div class="invalid-feedback form-error" >
                    <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

              </div>
              
               <b style="color: orange; font-size: 15px; " >*Wajib Diisi !</b>
                <br><br>
              <button type="submit" class="submit">Submit</button>
            </form>
      </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/mainku', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAM\xampp\htdocs\blog\resources\views/products/create_products.blade.php ENDPATH**/ ?>