@extends('master')

@section('judul', 'Halaman Tentang') 

@section('konten') 

 	<p>Ini adalah halaman tentang</p>
 	<p>Halaman ini dipanggil dengan menggunakan template, seruuu ya??? yuhuuu</p>

@endsection