@extends('master')

@section('judul', 'Halaman Home') 

@section('konten') 

 	<p>Ini adalah halaman home</p>
 	<p>Halaman ini dipanggil dengan menggunakan template, asik ya???</p>
 	
@endsection