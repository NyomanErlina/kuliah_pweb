<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function allUsers()
    {
        if(!Session::get('login')){
            return redirect('/login')->with('alert','Anda harus login terlebih dahulu.');
        }
        else{
              $user = User::all();
              return view('users.users', ['users' => $user]);
        }
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Session::get('login')){
            return redirect('/login')->with('alert','Anda harus login terlebih dahulu.');
        }
        else{
             return view('users.create_users');
        }
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate
        ([  'first_name' => 'required|max:50',
            'last_name' => 'required|max:50',
            'phone' => 'required|max:12',
            'email' => 'required|max:50',
            'password' => 'required|size:8',
            'job_status' => 'required|max:15'
        ]);

        $user = new User;
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->password = $request->password;
        $user->job_status = $request->job_status;
        
        $user->save();

        return redirect('/users')->with('status', 'Data User Berhasil Ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       if(!Session::get('login')){
            return redirect('/login')->with('alert','Anda harus login terlebih dahulu.');
        }
        else{
              $user = User::where('user_id', $id)->first();
              return view('users.edit_users', ['user' => $user]);
        }
       
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response


     */
    public function update(Request $request, $id)
    {
        $request->validate
        ([  'first_name' => 'required|max:50',
            'last_name' => 'required|max:50',
            'phone' => 'required|max:12',
            'email' => 'required|max:50',
            'password' => 'required|size:8',
            'job_status' => 'required|max:15'
        ]);


        $user = User::find($id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->phone = $request->phone;
        $user->email = $request->email;
        $user->password = $request->password;
        $user->job_status = $request->job_status;
        $user->save();

        return redirect('/users')->with('status', 'Data User Berhasil di Update.');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
        $user = User::where('user_id', $id);
        $user->delete(); 
        return redirect('/users')->with('status', 'Data User Berhasil Dihapus.');
    }


    public function trash()
    {
        if(!Session::get('login')){
            return redirect('/login')->with('alert','Anda harus login terlebih dahulu.');
        }
        else{
             //ngambil data yg udah dihapus :
        $users = User::onlyTrashed()->get();
        return view('/users/trash_users', ['users'=> $users] );
        }
        
    }

      public function restore($id)
    {
        //ngambil data yg udah dihapus :
        $users = User::onlyTrashed()->where('user_id', $id);
        $users->restore();
        return redirect('/users')->with('status', 'Data User yang Telah Dihapus Berhasil di Restore.');
    }

    public function restoreAll()
    {
        //ngambil data yg udah dihapus :
        $users = User::onlyTrashed();
        $users->restore();
        return redirect('/users')->with('status', 'Semua Data User yang Telah Dihapus Berhasil di Restore.');
    }



//login


    public function index(){
        if(!Session::get('login')){
            return redirect('/login')->with('alert','Anda harus login terlebih dahulu.');
        }
        else{
            return view('/menu/dashboard');
        }
    }

    public function login(){
        return view('/users/login');
    }

    public function loginPost(Request $request){

        $email = $request->email;
        $password = $request->password;

        $data = User::where('email',$email)->first();
        if($data){ //apakah email tersebut ada atau tidak
            if($data->password == $password){
                Session::put('user_id',$data->user_id);
                Session::put('first_name',$data->first_name);
                Session::put('last_name',$data->last_name);
                Session::put('email',$data->email);
                Session::put('job_status',$data->job_status);
                Session::put('login',TRUE);
                return redirect('/dashboard');
            }
            else{
                return redirect('/login')->with('alert','Email atau Password yang Anda Masukkan Salah.');
            }
        }
        else{
            return redirect('/login')->with('alert','Email atau Password yang Anda Masukkan Salah.');
        }
    }

    public function logout(){
        Session::flush();
        return redirect('/login')->with('alert','Anda sudah logout');
    }


}